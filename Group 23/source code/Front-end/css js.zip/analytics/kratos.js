
export class Kratos{
  constructor({...options}) {
    this.data = {
      currentPage: window.location.pathname,
      timestamp: new Date().toISOString().slice(0,10),
      userData: {
        guestId : localStorage.getItem('guestId'),
        browser : window.navigator.userAgentData.brands[2].brand,
        browserVersion : window.navigator.userAgentData.brands[2].version,
        platform : window.navigator.userAgentData.platform
      },
      scrollDetails: null,
    }
    
    this.interval = setInterval(() => {
      this.sendData();
    }, options.dataFrequency);
    this.currentTime = Date.now()
    this.previousScrollDepth = 0;
    this.currentScrollDepth = 0;
    this.scrollThresholds = [25, 50, 75, 100];
    
    this.url = options.url;
    this.updates = false;

    // Method bindings
    this.recordScrollDepth = this.recordScrollDepth.bind(this);
    this.recordTimeOnPage = this.recordTimeOnPage.bind(this);
    this.listenerAndFindOnce = this.listenerAndFindOnce.bind(this);
    this.sendData = this.sendData.bind(this);


    // Default Event Listeners
    // window.addEventListener('scroll', this.recordScrollDepth);
    window.addEventListener('beforeunload', (e) => {
      this.updates = true
      this.sendData();
      // e.returnValue = `Are you sure you want to leave`;
    });


    if(!this.data.userData.guestId){
      const fpPromise = import('https://openfpcdn.io/fingerprintjs/v3')
      .then(FingerprintJS => FingerprintJS.load())

      // Get the visitor identifier when you need it.
      fpPromise
        .then(fp => fp.get())
        .then(result => {
          // This is the visitor identifier:
          this.data.userData.guestId = result.visitorId
          localStorage.setItem('guestId', result.visitorId)
        })
    }
  }

  set(field, value) {
    this.data[field] = value;
  }

  recordScrollDepth() {
    // Calculate current scroll depth as a percentage of the document height
    this.currentScrollDepth = Math.round((window.scrollY / (document.documentElement.scrollHeight - window.innerHeight)) * 100);

    // Check if current scroll depth has passed any of the scroll thresholds
    for (let i = 0; i < this.scrollThresholds.length; i++) {
      if (this.currentScrollDepth >= this.scrollThresholds[i] && this.previousScrollDepth < this.scrollThresholds[i]) {
        this.data.scrollDetails ={
          scrollDepth: this.scrollThresholds[i],
          timestamp: new Date().toISOString()
        };
        // Update previous scroll depth
        this.previousScrollDepth = this.scrollThresholds[i];
        this.updates = true;
      }
    }

  }

  recordTimeOnPage() {
    // Calculate time spent on page as difference between current time and page load time
    this.data.timeSpentonPage = Date.now() - this.currentTime;
  
    // Remove event listener to prevent the method from being called multiple times
    // window.removeEventListener('beforeunload', this.recordTimeOnPage);
  }

  listenerAndFindOnce(trigger, element, arr) {
    if(!element && !trigger && !arr.length) {return false}
    const listener = (event) => {
      const id = event.target.id;
      arr.forEach((query) => {
        if(query == id){
          this.data[id] = true;
          console.log(this.data);
          this.updates = true;    // for update status
        }
      })
    }
    element.addEventListener(trigger, listener)
  }

  listenerforVideo(trigger, element, cb){
    this.data.video = {
      play: [],
      paused: [],
      seeking: false,
      seeked:[],
      states:{
        paused: false,
        seeked: false
      },
      rateChange: [],
      ended: false
    };
    element.addEventListener(trigger, (e) =>{
      switch (trigger) {
        case 'play':
          this.data.video.play.push(Math.round(e.target.currentTime));
          if(this.data.video.seeking){
            this.data.video.paused.pop();
            this.data.video.play.pop();
            this.data.video.seeking = false;
            this.data.video.states.play = false;
            this.data.video.states.paused = false;
            this.data.video.seeked.push(Math.round(e.target.currentTime))
          }
          this.data.video.states.play = true;
          break;
        case 'pause':
          this.data.video.paused.push(Math.round(e.target.currentTime));
          this.data.video.states.paused = true;
          break;
        case 'seeked':
          this.data.video.seeking = true;
          this.data.video.states.seeked = true;
          break;
        case 'ratechange':
          this.data.video.rateChange.push(e.target.playbackRate)
          break;
        case 'ended':
          this.data.video.ended = true;
          console.log('ended');
        break;
        default:
          cb();
          break;
      }
      this.updates = true;
    })
  }

  sendData(){
    if(this.updates){
      fetch(this.url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json; charset=UTF-8'
        },
        body: JSON.stringify(this.data)
      })
      .then(response => {
        this.print();
        console.log('sending data...');
        this.updates = false;
        if(this.data.video){
          this.data.video.states.paused = false;
          this.data.video.states.seeked = false;
          this.data.video.states.play = false;
          this.data.video.ended = false;
        }
      })
      .catch(error => {
        console.error('Error sending data:', error);
      });
      
    }
  }



  stopSendingData(){
    clearInterval(this.interval);
  }

  print(){
    console.log(this.data);
  }
}