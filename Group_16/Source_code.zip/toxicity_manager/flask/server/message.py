from flask import Blueprint, jsonify, render_template, request, flash, redirect, url_for, Response
import json
import pika

message = Blueprint('auth', __name__)

def string_from_qid(qid):
  return f'question_id=CAST(\'{qid}\' as uuid)'

@message.route("/test-flask", methods=['GET'])
def testFlask():
  return Response("Flask server is working", status=200, mimetype='application/json')

@message.route("/queue-survey", methods=['POST'])
def queueSurvey():
  # NOTE :- THIS WILL ACT LIKE THE PRODUCER

  # since we are not sending the request from the FORM the data is in the "request.data" parameter
  data = json.loads(request.data)

  surveyId = data['surveyId']

  connection_parameters = pika.ConnectionParameters("localhost")

  connection = pika.BlockingConnection(connection_parameters)

  # We don't directly deal with Connections, we interact with Channels
  channel = connection.channel()

  # IDEMPOTENT operation
  channel.queue_declare(queue="sanitize_survey_queue")

  # exchange='' :- means default exchange type
  # routing_key :- name of the queue we want to Publish to

  message = surveyId

  channel.basic_publish(exchange="", routing_key="sanitize_survey_queue", body=message)

  print(f"Sent message to the queue: ${message}")

  connection.close()

  return Response("Message added to the queue successfully", status=200, mimetype='application/json')
  