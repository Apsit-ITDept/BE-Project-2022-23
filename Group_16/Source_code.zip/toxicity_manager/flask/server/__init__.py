from flask import Flask
from os import path

def create_app():
    app = Flask(__name__)
    # This SECRET_KEY will be used to encrypt the cookies, session data related to our site
    app.config["SECRET_KEY"] = "lsdjflajslkdjflsjfljsldfjlaksjrtwer"

    from .message import message

    app.register_blueprint(message, url_prefix='/')

    return app