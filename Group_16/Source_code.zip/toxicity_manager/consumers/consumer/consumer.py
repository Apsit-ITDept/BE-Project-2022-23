import pika
import time
import random
from .connect import conn, cur
from  ai_models.Multi_Label_Classification_LR import analyze_data
from pprint import pprint

def string_from_qid(qid):
  return f'question_id=CAST(\'{qid}\' as uuid)'

def on_message_received(ch, method, properties, body):

    print("The body is ====> ", body)

    # convert byte string to string
    surveyId = body.decode('UTF-8')

    print(f'The surveyId is {surveyId}')

    cur.execute("SELECT * FROM public.\"Surveys\" WHERE id=CAST(%s as uuid);", (surveyId,))
    # select * from public."Surveys" where id=CAST('a9606715-c865-4f99-9afc-48b79af77caa' as uuid);

    survey = cur.fetchone()
    # survey is RealDictRow
    # get the "id", "form_title", "form_description" & "purpose"

    text_list = [survey['form_title'], survey['form_description'], survey['purpose']]

    print("===== THE SURVEY TEXT LIST ====")
    print(text_list)

    if survey is not None:
      print("Survey exists ===>")

      cur.execute("SELECT * FROM public.\"Questions\" WHERE survey_id=CAST(%s as uuid);", (surveyId,))
      # SELECT * FROM public."Questions" WHERE survey_id=CAST('a9606715-c865-4f99-9afc-48b79af77caa' as uuid);

      questions = cur.fetchall()
      # get the "id", "title" & "description"

      question_ids = []

      if len(questions) > 0:
        for question in questions:
          
          question_ids.append(question['id'])

          text_list.append(question['title'])
          text_list.append(question['description'])

        query = f'SELECT * FROM public.\"Options\" WHERE ({" OR ".join(list(map(string_from_qid, question_ids)))})'

        cur.execute(query)
        # SELECT * FROM public."Options" WHERE (question_id=CAST('1b0fede5-b1ab-427e-9a98-d135c5c6a4db' as uuid) OR question_id=CAST('13fa4dcd-b514-483e-b699-ba9efb17a836' as uuid) OR question_id=CAST('7950a4b1-175f-466f-a826-81bf51dd781e' as uuid) OR question_id=CAST('f0ec6990-a71e-425b-8690-cc621f072293' as uuid) OR question_id=CAST('4a6d9b57-3bf1-4267-bedc-99537fd677ff' as uuid) OR question_id=CAST('2840ba65-a591-46c0-8558-908c823b4bd7' as uuid));

        all_options = cur.fetchall()
        # get the "option_text"

        if len(all_options) > 0:
          for option in all_options:
            text_list.append(option['option_text'])
        else:
          print("CONSUMER ERROR :- Cannot add survey to the Sanitization Queue bcz Question doesn't have any options")

        print("===== THE TEXT LIST IS ======")

        print(text_list, len(text_list))

        data_sanitization_mapping = []

        # RUN THE ML CODE HERE
        for i in range(len(text_list)):
            # analyzer = LR_analyze_data()
            result = analyze_data(text_list[i])
            data_sanitization_mapping.append({
                'sentence' : text_list[i],
                'result': result
            })

        print("==========> The final result")
        pprint(data_sanitization_mapping)

        # HARMFUL TEXT
        harmful_text = []
        for sent_dict in data_sanitization_mapping:
          harmful = False
          harmful_list = {}
          for key in sent_dict["result"]:
            if sent_dict["result"][key] > 0.6:
              harmful_list[key] = sent_dict["result"][key]
              harmful = True
          if harmful:
            harmful_text.append({"sentence": sent_dict["sentence"], "probabilities": harmful_list})
        
        print("=======> The harmful_text list is")
        pprint(harmful_text)
      else:
        print("CONSUMER ERROR :- Cannot add survey to the Sanitization Queue bcz Survey doesn't hv any questions")

    else:
      print("CONSUMER ERROR :- Cannot add survey to the Sanitization Queue bcz survey doesn't exist")

    time.sleep(random.randint(2,4))

    # MANUALLY ACKNOWLEDGE AFTER PROCESSING IS COMPLETE
    ch.basic_ack(delivery_tag=method.delivery_tag)
    print("============= Finished processing the data ===============")


def run_mq(consumer_name):
  connection_parameters = pika.ConnectionParameters("localhost")

  connection = pika.BlockingConnection(connection_parameters)

    # We don't directly interact with Connections, we interact with Channels
  channel = connection.channel()

    # creating the queue :- IDEMPOTENT operation means it will be declared only once.
  channel.queue_declare(queue="sanitize_survey_queue")

    # As discussed in README.md. Each Consumer will only process a single message at a time.
    # DEFAULT IS ROUND ROBIN
  channel.basic_qos(prefetch_count=1)

    # REMOVED auto_ack :- Don't automatically acknowledge after consuming from the queue
  channel.basic_consume(
      queue="sanitize_survey_queue", on_message_callback=on_message_received
  )

  print(f"============== Consumer '{consumer_name}' is up & running ==============")

  channel.start_consuming()