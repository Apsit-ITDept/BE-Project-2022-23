    data = [{x: 5, y: 10}, {x: 8, y: 18},{x: 16, y: 14}, {x: 26, y: 20},
    {x: 27, y: 25}, {x: 30, y: 30},{x: 32, y: 21}, {x: 35, y: 15},
    {x: 40, y: 24}, {x: 48, y: 30},{x: 55, y: 36}, {x: 62, y: 44},
    {x: 72, y: 50}, {x: 76, y: 46},{x: 80, y: 42}, {x: 82, y: 50},
    {x: 86, y: 56}, {x: 93, y: 60},{x: 102, y: 68}, {x: 113, y: 70},
    {x: 115, y: 67}, {x: 118, y: 62},{x: 120, y: 55}, {x: 123, y: 50},
    {x: 124, y:53}, {x: 129, y: 46},{x: 132, y:42}, {x: 135, y: 45},
    {x: 140, y:54}, {x: 146, y: 59},{x: 153, y:52}, {x: 159, y: 59},
    {x: 163, y:70}, {x: 170, y: 95},{x: 173, y:115}, {x: 180, y:144}]

    // window.addEventListener('load', () => {selectFunction(0)} );

    document.getElementById("seek-time").onchange=function(){selectFunction(document.getElementById("seek-time").value)};



var bounceLabels =[];
var bounceData = [];
var studentPageViewLabels = [];
var studentPageViewData = [];
var studentEnrollData = [];

// Define the URL of the endpoint for fetching course data
const url = new URL('http://localhost:5000/analytics/get-coursedata/:courseid');

// Replace :courseid with the actual ID of the course you want to fetch
const courseId = '641c684706ec5d6413405853';
url.pathname = url.pathname.replace(':courseid', courseId);

// Make a fetch request to the API endpoint
fetch(url)
  .then(response => response.json())
  .then(data => {

//-------------------------------------------------------------------------------------------------------------------------------------------------

    // Page View & Enrollment Calculation
    let pointer = ((data.data.pageViews.length-7)<0)?0:data.data.pageViews.length-7;
    let point = ((data.data.enroll.length-7)<0)?0:data.data.enroll.length-7;;
    while(pointer < data.data.pageViews.length){
        
        const dateString = data.data.pageViews[pointer].timestamp;
        const date = new Date(dateString);
  
        const option = {
          day: 'numeric',
          month: 'short',
          year: 'numeric'
        };
        const formattedDate = date.toLocaleDateString('en-US', option);
  
        const parts = formattedDate.split(' ');
        const reorderedDate = parts[1] + ' ' + parts[0];
        studentPageViewLabels.push(reorderedDate);
        studentPageViewData.push(data.data.pageViews[pointer].hits)
        if(data.data.pageViews[pointer].timestamp == data.data.enroll[point].timestamp){
            studentEnrollData.push(data.data.enroll[point].hits);
            point++;
        }else{
            studentEnrollData.push(0);
        }
        pointer++;
        }
        pageViewChart.update();


//---------------------------------------------------------------------------------------------------------------------------------------------
    // Bounce Rate Calculation
    pointer = ((data.data.bounceRates.length-7)<0)?0:data.data.bounceRates.length-7;
    // Do something with the returned data
    while(pointer < data.data.bounceRates.length){
      const dateString = data.data.bounceRates[pointer].timestamp;
      const date = new Date(dateString);

      const option = {
        day: 'numeric',
        month: 'short',
        year: 'numeric'
      };
      const formattedDate = date.toLocaleDateString('en-US', option);

      const parts = formattedDate.split(' ');
      const reorderedDate = parts[1] + ' ' + parts[0];
      bounceLabels.push(reorderedDate);
      bounceData.push(data.data.bounceRates[pointer].hits);
      pointer++;
      }
      bounceRateChart.update();
      if(data.data.bounceRates.length>1){
        percentageUpdate(data.data.bounceRates[data.data.bounceRates.length-2].hits,data.data.bounceRates[data.data.bounceRates.length-1].hits);
      }

    })
  .catch(error => {
    console.error('Error fetching course data:', error);
  });

//-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  function percentageUpdate(prev,curr){
    if(curr>prev){
      let percentage = (((curr)/prev)*100-100);
      document.getElementById("bounceRatePercentage").innerHTML = `(<span class="font-weight-bolder text-danger">${Math.round(percentage)}%</span>) increase in todays Bounce Rate. `
    }else if(prev>curr){
      let percentage = ((prev-curr)/prev)*100;
      document.getElementById("bounceRatePercentage").innerHTML = `(<span class="font-weight-bolder text-success">${Math.round(percentage)}%</span>) decrease in todays Bounce Rate. `
    }else{
      document.getElementById("bounceRatePercentage").innerHTML = `(<span class="font-weight-bolder">0%</span>) increase/decrease in todays Bounce Rate. `
    }
  }

//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ 

let moduleLabels = [];
let moduleData = [];
let moduleIds = null;
const pieUrl = new URL('http://localhost:5000/analytics/get-moduledata/:courseid');

// Replace :courseid with the actual ID of the course you want to fetch
pieUrl.pathname = pieUrl.pathname.replace(':courseid', courseId);

// Make a fetch request to the API endpoint
fetch(pieUrl)
  .then(response => response.json())
  .then(data => {
    let module = Object.keys(data.data);
    module.forEach(element => {
        const parts = element.split('-');
        moduleLabels.push(parts[0]);
    });
    modData = Object.values(data.data);
    modData.forEach(element => {
        moduleData.push(element);
    });
    moduleIds = Object.values(data.ids);
    let options = '';
    moduleLabels.forEach((e,index) => {
        document.getElementById('seek-time').innerHTML += `<option value = "${index}" >${e}</option>`
    })
    modulePreferences.update();
  })
  .catch(error => {
    console.error('Error fetching course data:', error);
  });


  //-------------------------------------------------------------------------------------------------------------------------------------------------------------
    async function selectFunction(index){
        let moduleUpdatedData = await fetchModule(moduleIds[index]);
        let pauseData = formatScatterPlot(moduleUpdatedData.pause);
        let playData = formatScatterPlot(moduleUpdatedData.play);
        let seekTimeData = formatScatterPlot(moduleUpdatedData.seekTime);
        let rateChangeData = rateCal(moduleUpdatedData.rateChange);

        console.log(moduleUpdatedData);

        scatterChart.data.datasets[0].data = [{x:0,y:null},...seekTimeData];
        scatterChartPause.data.datasets[0].data = [{x:0,y:null},...pauseData];
        scatterChartPlay.data.datasets[0].data = [{x:0,y:null},...playData];        
        scatterChartRateChange.data.datasets[0].data = rateChangeData;        

        scatterChart.update();
        scatterChartPause.update();
        scatterChartPlay.update();
        scatterChartRateChange.update();
    }

    function fetchModule(id) {
        const scatterUrl = new URL('http://localhost:5000/analytics/course/:courseid/get-modulevideo/:moduleid');
        scatterUrl.pathname = scatterUrl.pathname.replace(':courseid', courseId);
        scatterUrl.pathname = scatterUrl.pathname.replace(':moduleid', id);
        return fetch(scatterUrl)
        .then(response => response.json())
        .then(data => {
             let returnData = {
                pause: data.data.pause,
                play: data.data.play,
                seekTime: data.data.seekTime,
                rateChange: data.data.rateChange,
             }
            return returnData;
            });
    }

    function formatScatterPlot(obj){
        const formattedData = [];
        for (let item in obj){
            let num = parseInt(item);
            if(num === 0 || !num){
                continue;
            }
            formattedData.push({x:num,y:obj[item]});
            
        }
        return formattedData;
    }


    function rateCal(obj){
        let rateDataObj = [0,0,0,0,0,0,0,0];
        for (let item in obj){
            switch (item) {
                case '0-25':
                    rateDataObj[0] = (obj[item] || 0)
                    break;
                case '0-5':
                    rateDataObj[1] = (obj[item] || 0)
                    break;
                case '0-75':
                    rateDataObj[2] = (obj[item] || 0)
                    break;
                case '1':
                    rateDataObj[3] = (obj[item] || 0)
                    break;
                case '1-25':
                    rateDataObj[4] = (obj[item] || 0)
                    break;
                case '1-5':
                    rateDataObj[5] = (obj[item] || 0)
                    break;
                case '1-75':
                    rateDataObj[6] = (obj[item] || 0)
                    break;
                case '2':
                    rateDataObj[7] = (obj[item] || 0)
                    break;
            }
            
        }
        console.log(rateDataObj);
        return rateDataObj;
    }
//------------------------------------------------------------------------------------------------------------------------------------------------

//                                                    Chart Configuration

//---------------------------------------------------------------------------------------------------------------------------------------------------
    var ctx = document.getElementById("chart-bars").getContext("2d");

    var pageViewChart = new Chart(ctx, {
      
      data: {
        labels: studentPageViewLabels,
        datasets: [{
          type: "bar",
          label: "Students Visited",
          tension: 0.4,
          borderWidth: 0,
          borderRadius: 4,
          borderSkipped: false,
          backgroundColor: "rgba(255, 255, 255, .8)",
          data: studentPageViewData,
          maxBarThickness: 6
        }, {
          type : "line",
          label: "Students Enrolled",
          tension: 0,
          borderWidth: 0,
          pointRadius: 5,
          pointBackgroundColor: "rgba(255, 255, 255, .8)",
          pointBorderColor: "transparent",
          borderColor: "rgba(255, 255, 255, .8)",
          borderColor: "rgba(255, 255, 255, .8)",
          borderWidth: 4,
          backgroundColor: "transparent",
          fill: true,
          data: studentEnrollData,
          maxBarThickness: 6

        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false,
          }
        },
        interaction: {
          intersect: false,
          mode: 'index',
        },
        scales: {
          y: {
            grid: {
              drawBorder: false,
              display: true,
              drawOnChartArea: true,
              drawTicks: false,
              borderDash: [5, 5],
              color: 'rgba(255, 255, 255, .2)'
            },
            ticks: {
              suggestedMin: 0,
              suggestedMax: 500,
              beginAtZero: true,
              padding: 10,
              font: {
                size: 14,
                weight: 300,
                family: "Roboto",
                style: 'normal',
                lineHeight: 2
              },
              color: "#fff"
            },
          },
          x: {
            grid: {
              drawBorder: false,
              display: true,
              drawOnChartArea: true,
              drawTicks: false,
              borderDash: [5, 5],
              color: 'rgba(255, 255, 255, .2)'
            },
            ticks: {
              display: true,
              color: '#f8f9fa',
              padding: 10,
              font: {
                size: 14,
                weight: 300,
                family: "Roboto",
                style: 'normal',
                lineHeight: 2
              },
            }
          },
        },
      },
    });

//----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    var ctx2 = document.getElementById("chart-line").getContext("2d");

    var bounceRateChart = new Chart(ctx2, {
      type: "bar",
      data: {
        labels: bounceLabels,
        datasets: [{
          label: "Bounce Rate",
          tension: 0,
          borderWidth: 0,
          pointRadius: 5,
          pointBackgroundColor: "rgba(255, 255, 255, .8)",
          pointBorderColor: "transparent",
          borderColor: "rgba(255, 255, 255, .8)",
          borderColor: "rgba(255, 255, 255, .8)",
          borderWidth: 4,
          backgroundColor: "transparent",
          fill: true,
          data: bounceData,
          maxBarThickness: 6

        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false,
          }
        },
        interaction: {
          intersect: false,
          mode: 'index',
        },
        scales: {
          y: {
            grid: {
              drawBorder: false,
              display: true,
              drawOnChartArea: true,
              drawTicks: false,
              borderDash: [5, 5],
              color: 'rgba(255, 255, 255, .2)'
            },
            ticks: {
              display: true,
              color: '#f8f9fa',
              padding: 10,
              font: {
                size: 14,
                weight: 300,
                family: "Roboto",
                style: 'normal',
                lineHeight: 2
              },
            }
          },
          x: {
            grid: {
              drawBorder: false,
              display: false,
              drawOnChartArea: false,
              drawTicks: false,
              borderDash: [5, 5]
            },
            ticks: {
              display: true,
              color: '#f8f9fa',
              padding: 10,
              font: {
                size: 14,
                weight: 300,
                family: "Roboto",
                style: 'normal',
                lineHeight: 2
              },
            }
          },
        },
      },
    });

//--------------------------------------------------------------------------------------------------------------------------------------------------------------------

    var ctx3 = document.getElementById("chart-line-tasks").getContext("2d");

    var scatterChart = new Chart(ctx3, {
      type: "scatter",
      data: {
        datasets: [{
          label: "count",
          tension: 0,
          borderWidth: 0,
          pointRadius: 3,
          pointBackgroundColor: "rgba(255, 255, 255, .8)",
          pointBorderColor: "transparent",
          borderColor: "rgba(255, 255, 255, .8)",
          borderWidth: 4,
          backgroundColor: "transparent",
          fill: true,
          data: data,
          maxBarThickness: 6

        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false,
          }
        },
        interaction: {
          intersect: false,
          mode: 'index',
        },
        scales: {
          y: {
            grid: {
              drawBorder: false,
              display: true,
              drawOnChartArea: true,
              drawTicks: false,
              borderDash: [5, 5],
              color: 'rgba(255, 255, 255, .2)'
            },
            ticks: {
              display: true,
              padding: 10,
              color: '#f8f9fa',
              font: {
                size: 14,
                weight: 300,
                family: "Roboto",
                style: 'normal',
                lineHeight: 2
              },
            }
          },
          x: {
            grid: {
              drawBorder: false,
              display: false,
              drawOnChartArea: false,
              drawTicks: false,
              borderDash: [5, 5]
            },
            ticks: {
              display: true,
              color: '#f8f9fa',
              padding: 10,
              font: {
                size: 14,
                weight: 300,
                family: "Roboto",
                style: 'normal',
                lineHeight: 2
              },
            }
          },
        },
      },
    });





//------------------------------------------------------------------------------------------------------------------------------------------------------------------

    var ctx3 = document.getElementById("chart-doughnut").getContext("2d");

    var modulePreferences = new Chart(ctx3, {
      
      type: "doughnut",
      data: {
        labels: moduleLabels,
        datasets: [{
          tension: 0,
          borderWidth: 0,
          pointRadius: 3,
          pointBackgroundColor: "rgba(255, 255, 255, .8)",
          pointBorderColor: "transparent",
          borderColor: "rgba(255, 255, 255, .8)",
          borderWidth: 0,
          backgroundColor: "transparent",
          fill: true,
          data: moduleData,
          backgroundColor: [
      '#ed0552',
      '#022edb',
      '#e8e400',
      '#e505ed',
      '#581845'
    ],

        }],
        hoverOffset: 4
      },
      
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: true,
            labels:{
              color: "white",
            }
          }
        },
        interaction: {
          intersect: false,
          mode: 'index',
        },
      },
    });

//-----------------------------------------------------------------------------------------------------------------------------

var ctx3 = document.getElementById("chart-play-tasks").getContext("2d");

    var scatterChartPlay = new Chart(ctx3, {
      type: "scatter",
      data: {
        datasets: [{
          label: "count",
          tension: 0,
          borderWidth: 0,
          pointRadius: 3,
          pointBackgroundColor: "rgba(255, 255, 255, .8)",
          pointBorderColor: "transparent",
          borderColor: "rgba(255, 255, 255, .8)",
          borderWidth: 4,
          backgroundColor: "transparent",
          fill: true,
          data: data,
          maxBarThickness: 6

        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false,
          }
        },
        interaction: {
          intersect: false,
          mode: 'index',
        },
        scales: {
          y: {
            grid: {
              drawBorder: false,
              display: true,
              drawOnChartArea: true,
              drawTicks: false,
              borderDash: [5, 5],
              color: 'rgba(255, 255, 255, .2)'
            },
            ticks: {
              display: true,
              padding: 10,
              color: '#f8f9fa',
              font: {
                size: 14,
                weight: 300,
                family: "Roboto",
                style: 'normal',
                lineHeight: 2
              },
            }
          },
          x: {
            grid: {
              drawBorder: false,
              display: false,
              drawOnChartArea: false,
              drawTicks: false,
              borderDash: [5, 5]
            },
            ticks: {
              display: true,
              color: '#f8f9fa',
              padding: 10,
              font: {
                size: 14,
                weight: 300,
                family: "Roboto",
                style: 'normal',
                lineHeight: 2
              },
            }
          },
        },
      },
    });


//----------------------------------------------------------------------------------------------------------------------------------------------

var ctx3 = document.getElementById("chart-pause-tasks").getContext("2d");

    var scatterChartPause = new Chart(ctx3, {
      type: "scatter",
      data: {
        datasets: [{
          label: "count",
          tension: 0,
          borderWidth: 0,
          pointRadius: 3,
          pointBackgroundColor: "rgba(255, 255, 255, .8)",
          pointBorderColor: "transparent",
          borderColor: "rgba(255, 255, 255, .8)",
          borderWidth: 4,
          backgroundColor: "transparent",
          fill: true,
          data: data,
          maxBarThickness: 6

        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false,
          }
        },
        interaction: {
          intersect: false,
          mode: 'index',
        },
        scales: {
          y: {
            grid: {
              drawBorder: false,
              display: true,
              drawOnChartArea: true,
              drawTicks: false,
              borderDash: [5, 5],
              color: 'rgba(255, 255, 255, .2)'
            },
            ticks: {
              display: true,
              padding: 10,
              color: '#f8f9fa',
              font: {
                size: 14,
                weight: 300,
                family: "Roboto",
                style: 'normal',
                lineHeight: 2
              },
            }
          },
          x: {
            grid: {
              drawBorder: false,
              display: false,
              drawOnChartArea: false,
              drawTicks: false,
              borderDash: [5, 5]
            },
            ticks: {
              display: true,
              color: '#f8f9fa',
              padding: 10,
              font: {
                size: 14,
                weight: 300,
                family: "Roboto",
                style: 'normal',
                lineHeight: 2
              },
            }
          },
        },
      },
    });

//-----------------------------------------------------------------------------------------------------------------------------------------------


var ctx3 = document.getElementById("chart-rateChange-tasks").getContext("2d");

    var scatterChartRateChange = new Chart(ctx3, {
      type: "bar",
      data: {
        labels: ['0.25','0.5','0.75','1','1.25','1.5','1.75','2'],
        datasets: [{
          label: "count",
          tension: 0,
          borderWidth: 0,
          pointRadius: 3,
          pointBackgroundColor: "rgba(255, 255, 255, .8)",
          pointBorderColor: "transparent",
          borderColor: "rgba(255, 255, 255, .8)",
          borderWidth: 4,
          backgroundColor: "transparent",
          fill: true,
          data: data,
          maxBarThickness: 6

        }],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: false,
          }
        },
        interaction: {
          intersect: false,
          mode: 'index',
        },
        scales: {
          y: {
            grid: {
              drawBorder: false,
              display: true,
              drawOnChartArea: true,
              drawTicks: false,
              borderDash: [5, 5],
              color: 'rgba(255, 255, 255, .2)'
            },
            ticks: {
              display: true,
              padding: 10,
              color: '#f8f9fa',
              font: {
                size: 14,
                weight: 300,
                family: "Roboto",
                style: 'normal',
                lineHeight: 2
              },
            }
          },
          x: {
            grid: {
              drawBorder: false,
              display: false,
              drawOnChartArea: false,
              drawTicks: false,
              borderDash: [5, 5]
            },
            ticks: {
              display: true,
              color: '#f8f9fa',
              padding: 10,
              font: {
                size: 14,
                weight: 300,
                family: "Roboto",
                style: 'normal',
                lineHeight: 2
              },
            }
          },
        },
      },
    });
