# REFER KAGGLE NOTEBOOk
# https://www.kaggle.com/code/coolparth/classifying-multi-label-comments-0-9741-lb/edit
import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
import seaborn as sns
from pprint import pprint
import re
import sys
import pickle
# from ai_models import analyze_data


def breakline():
    print("========================================")


def train_model():

    train_df = pd.read_csv('./train.csv')
    test_df = pd.read_csv('./test.csv')

    print(train_df.sample(20))
    breakline()

    cols_target = ['obscene','insult','toxic','severe_toxic','identity_hate','threat']

    print(train_df.describe())
    # As the mean values are very small (some way below 0.05), there would be many not labelled as positive in the six categories.
    # From this I guess that there would be many comments which are not labelled in any of the six categories. Let's take a look.
    breakline()

    print(train_df['toxic']!=1)
    breakline()
    # None of them is 1 those are unlabelled comments
    unlabelled_in_all = train_df[(train_df['toxic']!=1) & (train_df['severe_toxic']!=1) & (train_df['obscene']!=1) &
                                (train_df['threat']!=1) & (train_df['insult']!=1) & (train_df['identity_hate']!=1)]
    print('Percentage of unlabelled comments is ', len(unlabelled_in_all)/len(train_df)*100)
    breakline()

    # check for any 'null' comment
    no_comment = train_df[train_df['comment_text'].isnull()]
    print("Number of comments in Training Dataset whose \"comment_text\" is null :- ",len(no_comment))
    breakline()

    print(test_df.sample(10))
    breakline()

    no_comment = test_df[test_df['comment_text'].isnull()]
    print("Number of comments in Testing Dataset whose \"comment_text\" is null :- ",len(no_comment))
    breakline()

    # let's see the total rows in train, test data and the numbers for the various categories
    print('Total rows in test is :- {}'.format(len(test_df)))
    print('Total rows in train is :- {}'.format(len(train_df)))
    breakline()
    print("Sum of all the columns' values :- \n", train_df[cols_target].sum())
    breakline()

    # As mentioned earlier, majority of the comments in the training data are not labelled in one or more of these categories.

    # Let's look at the character length for the rows in the training data and record these
    train_df['char_length'] = train_df['comment_text'].apply(lambda x: len(str(x)))
    print("You can see the \"char_length\" column")
    print(train_df.head())
    breakline()
    print("train_df.shape :- ", train_df.shape)

    # FIGURE 1
    # # 1st way to create a histogram
    # # look at the histogram plot for text length
    # sns.set()
    # train_df['char_length'].hist()
    # plt.title("train_df['char_length'].hist()")
    # plt.show()
    # # Most of the text length are within 500 characters, with some up to 5,000 characters long.

    data = train_df[cols_target]
    print(data.head())
    breakline()

    # FIGURE 3
    # # gradient color
    # colormap = plt.cm.plasma
    # # figsize => Width, height in inches.
    # plt.figure(figsize=(7,7))
    # # y => vertical Axes loation for the title (1.0 is the top).
    # # size =>
    # plt.title('Correlation of targets with each other',y=1.05,size=14)
    # # HeatMap :- a representation of data in the form of a map or diagram in which data values are represented as colours
    # sns.heatmap(data.astype(float).corr(),linewidths=0.1,vmax=1.0,square=True,cmap=colormap,
    #            linecolor='white',annot=True)
    # plt.show()

    # Indeed, it looks like some of the labels are higher correlated,
    # e.g. insult-obscene has the second-highest at 0.74, followed by toxic-obscene and toxic-insult.

    # Let's look at the character length for the rows in the testing data and record these
    test_df['char_length'] = test_df['comment_text'].apply(lambda x: len(str(x)))

    # FIGURE 2
    # # 2nd way to create a histogram
    # plt.figure()
    # plt.hist(test_df['char_length'])
    # plt.title("test_df['char_length'].hist()")
    # plt.show()

    # We can also do Stemming here but it is more useful in Neural Networds
    def clean_text(text):
        text = text.lower()
        text = re.sub(r"what's", "what is ", text)
        text = re.sub(r"\'s", " ", text)
        text = re.sub(r"\'ve", " have ", text)
        text = re.sub(r"can't", "cannot ", text)
        text = re.sub(r"n't", " not ", text)
        text = re.sub(r"i'm", "i am ", text)
        text = re.sub(r"\'re", " are ", text)
        text = re.sub(r"\'d", " would ", text)
        text = re.sub(r"\'ll", " will ", text)
        text = re.sub(r"\'scuse", " excuse ", text)
        # \w :- small "w" is a-z, A-Z, 0-9, _
        # \W :- It is anything except the above
        text = re.sub('\W', ' ', text)
        # \s+ :- multiple whitespace characters
        text = re.sub('\s+', ' ', text)
        text = text.strip(' ')
        return text

    # ====> Define X from entire train & test data for use in tokenization by Vectorizer¶

    # clean the comment_text in train_df
    train_df['comment_text'] = train_df['comment_text'].map(lambda com : clean_text(com))

    # clean the comment_text in test_df
    test_df['comment_text'] = test_df['comment_text'].map(lambda com : clean_text(com))

    train_df = train_df.drop('char_length',axis=1)

    X = train_df.comment_text
    test_X = test_df.comment_text

    print("Both X & test_X are arrays of comments_text :- ", X.shape, test_X.shape)
    breakline()

    # ====> VECTORIZE THE DATA

    # Convert a collection of text documents to a matrix of token counts.
    from sklearn.feature_extraction.text import TfidfVectorizer
    # https://scikit-learn.org/stable/modules/generated/sklearn.feature_extraction.text.TfidfTransformer.html
    # https://scikit-learn.org/stable/modules/generated/sklearn.feature_extraction.text.TfidfVectorizer.html
    vect = TfidfVectorizer(max_features=5000,stop_words='english')
    print("The tfidf vector is :- \n", vect)
    breakline()


    # learn the vocabulary in the training data, then use it to create a document-term matrix
    X_dtm = vect.fit_transform(X)
    # examine the document-term matrix created from X_train
    # X_dtm is of type "scipy.sparse.csr_matrix"
    print("X_dtm.toarray() :- \n", X_dtm.toarray())
    breakline()

    # print("'test_X' Column is :- ", test_X.tolist())

    test_X_dtm = vect.transform(test_X)
    # examine the document-term matrix from X_test
    # test_X_dtm is of type "scipy.sparse.csr_matrix"
    print("test_X_dtm.toarray() :- \n", test_X_dtm.toarray())

    # import and instantiate the Logistic Regression model
    from sklearn.linear_model import LogisticRegression
    from sklearn.metrics import accuracy_score
    logreg = LogisticRegression(C=12.0, max_iter=10000)

    # create submission file
    sub_bin = pd.read_csv('./sample_submission.csv')

    for label in cols_target:
        print('... Processing {}'.format(label))
        # taking only 1 target column at a time
        y = train_df[label]
        # train the model using X_dtm & y
        logreg.fit(X_dtm, y)
        # compute the training accuracy
        y_pred_X = logreg.predict(X_dtm)
        print("y_pred_X", y_pred_X)
        print('Training accuracy is {}'.format(accuracy_score(y, y_pred_X)))
        test_y_prob = logreg.predict_proba(test_X_dtm)[:, 1]
        # test_y_full = logreg.predict_proba(test_X_dtm)
        # print("=====> test_y_full",test_y_full)
        # RETURNS AN ARRAY OF 2 Elements see in README.md
        print("=====> test_y_prob",test_y_prob)
        print("The predicted probabilites")
        sub_bin[label] = test_y_prob

        lr_file_name = "mlc_lr_" + label + ".pickle"

        with open(lr_file_name, "wb") as f:
            # wb :- write binary mode
            pickle.dump(logreg, f)


    print("==========> sub_bin")
    print(sub_bin.head())
    breakline()
    print(test_X.iloc[0])
    print(sub_bin.iloc[0])
    print(test_X.iloc[6])
    print(sub_bin.iloc[6])
    print(test_X.iloc[56])
    print(sub_bin.iloc[56])
    print(test_X.iloc[4])
    print(sub_bin.iloc[4])

    with open("mlc_vec.pickle", "wb") as f:
        pickle.dump(vect, f)

CWD = r"C:\Users\Parth979\Documents\workspace\CoinPlanet\toxicity_manager\consumers\ai_models\\"

def analyze_data(text):
    cols_target = ['obscene', 'insult', 'toxic', 'severe_toxic', 'identity_hate', 'threat']

    with open(CWD+"mlc_vec.pickle", "rb") as f:
        vectorizer = pickle.load(f)

    # Convert to an object
    cols_target_obj = {}
    for target_name in cols_target:
        cols_target_obj[target_name] = 0.5

    # text_list_2 = []
    # test_text = "You have done a great job team."

    # test_text_dtm = vectorizer.transform([text_list_2.extend(text_list)])

    test_text_dtm = vectorizer.transform([text])

    # print(test_text_dtm.toarray())

    for label in cols_target:
        lr_file_name = CWD + "mlc_lr_" + label + ".pickle"

        with open(lr_file_name, "rb") as pickle_mlc_lr:
            lr_model = pickle.load(pickle_mlc_lr)

        test_text_prob = lr_model.predict_proba(test_text_dtm)[:, 1]

        cols_target_obj[label] = test_text_prob
        # print("prob for", label, "is :- ", test_text_prob)

    # print("====> The predicted probability of text", cols_target_obj)
    return cols_target_obj

# if this file is RUN DIRECTLY
if __name__ == '__main__':
    try:
        print("Running ......")
        # # filename is the first argument

        if len(sys.argv) <= 2:
            exit("Please enter the mode by \nRun the file like this :- python file_name.py --mode test")
        elif(sys.argv[1].lower() != "--mode") and ((sys.argv[2].lower() != "test") or (sys.argv[2].lower() != "train")):
            exit("Please enter the mode by \nRun the file like this :- python file_name.py --mode test")
        elif sys.argv[2].lower() == "train":
            train_model()
        elif sys.argv[2].lower() == "test":
            data = ["You fucking idiot can't even do a simple thing", "This is very cool", "You piece of shit can't even do a simple thing",
                    "This is a normal sentence", "I will burn you to hell if you don't do what i tell u"
                    ]
            data_sanitization_mapping = []
            for i in range(len(data)):
                result = analyze_data(data[i])
                data_sanitization_mapping.append({
                    'sentence' : data[i],
                    'result': result
                })


            print("==========> The final result")
            pprint(data_sanitization_mapping)

    except Exception as e:
        print("===== An error occurred while running the file =====")
        print(e)

