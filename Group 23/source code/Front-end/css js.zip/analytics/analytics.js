import {Kratos} from "./kratos.js"


// Initialize unique user hash
const options = {
  dataFrequency: 5000,
  url: 'http://localhost:5000/analytics/record-userdata'
}
const kratos = new Kratos(options)
kratos.set("courseId", "641c684706ec5d6413405853");
// kratos.print()
// setTimeout(() => kratos.print(), 5000)
// setTimeout(() => kratos.sendData(), options.dataFrequency)
if(window.location.pathname == '/Achieving_Personal_and_Professional_Success.html'){
  const courseSidebar = document.querySelector('#course-left-sidebar')
  const courseContent = document.querySelector('#course-content')
  kratos.listenerAndFindOnce('click', courseSidebar, ['enrollButton'])
  kratos.listenerAndFindOnce('mouseover', courseSidebar, ['courseDetails'])
  kratos.listenerAndFindOnce('mouseover', courseContent, ['courseDescription', 'review'])
}


if(['/introduction.html' , '/module1.html' , '/module2.html' , '/module3.html' , '/module4.html']
.indexOf(window.location.pathname) + 1){
  const video = document.querySelector('#video')

  kratos.listenerforVideo('seeked', video )
  kratos.listenerforVideo('ratechange', video)
  kratos.listenerforVideo('pause', video)
  kratos.listenerforVideo('play', video)
  kratos.listenerforVideo('ended', video)
}